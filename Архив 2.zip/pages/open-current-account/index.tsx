import Layout from "../../components/Layout";
import React from "react";
import { Slider, Benefits, Order, News } from "../../components";
import api from "../../api/Api";
import { SliderProps } from "../../interfaces";
import { BccTypography, BccCardFull } from "../../components/BccComponents";

const OpenCurrentAccountPage = () => {
  const [slider, setSlider] = React.useState<SliderProps[] | []>([]);
  React.useEffect(() => {
    api.main.getSlider(window.location.pathname).then((res: SliderProps[]) => {
      setSlider(res);
    });
  }, []);
  return (
    <Layout title="Business">
      <div className="main-page">
        <div className="container">
          <Slider slider={slider} />
          <Benefits
            items={[
              {
                title: "В любой валюте",
                desc: "Открытие счёта в любой  валюте бесплатно",
                img: "/img/icons/cur.svg",
              },
              {
                title: "На любую сумму",
                desc: "Документ, удостоверяющий личность, содержащий ИИН",
                img: "/img/icons/zp.svg",
              },
              {
                title: "Один документ",
                desc: "Документ, удостоверяющий личность, содержащий ИИН",
                img: "/img/icons/doc.svg",
              },
            ]}
          />
          <Order title="Открыть текущий счёт" />
          <BccCardFull
            chips={[
              {
                title: "Мобильный банкинг",
                type: "outlined",
                color: "secondary",
              },
            ]}
            title="BCC.KZ"
            text={
              <>
                <BccTypography align="left" block type="p2" mb="32px">
                  Управляй банковскими счетами онлайн через браузер или
                  приложение
                </BccTypography>
                <img style={{ marginRight: 20 }} src={"/img/as.svg"} />
                <img src={"/img/gp.svg"} />
              </>
            }
            bgImg="/img/mobile-app.svg"
          />
          <News />
        </div>
      </div>
    </Layout>
  );
};
export default OpenCurrentAccountPage;
