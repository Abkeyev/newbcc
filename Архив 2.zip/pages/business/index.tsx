import React from "react";
import Layout from "../../components/Layout";
import { Slider, Best, BusinessCards, News } from "../../components";
import { SliderProps } from "../../interfaces";
import api from "../../api/Api";

const BusinessPage = () => {
  const [slider, setSlider] = React.useState<SliderProps[] | []>([]);

  React.useEffect(() => {
    const path = window.location.pathname;
    api.main.getSlider(path).then((res: SliderProps[]) => {
      setSlider(res);
    });
  }, []);
  return (
    <Layout title="Бизнес клиентам">
      <div className="main-page">
        <div className="container">
          <Slider slider={slider} />
          <Best />
          <BusinessCards/>
          <News />
        </div>
      </div>
    </Layout>
  );
};

export default BusinessPage;
