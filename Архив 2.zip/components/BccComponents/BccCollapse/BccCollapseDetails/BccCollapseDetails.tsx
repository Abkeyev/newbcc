import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails'
import { withStyles } from '@material-ui/core/styles'

const BccCollapseDetails = withStyles({
  root: {},
})(ExpansionPanelDetails)

export default BccCollapseDetails
