import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary'
import { withStyles } from '@material-ui/core/styles'

const BccCollapseTitle = withStyles({
  root: {},
})(ExpansionPanelSummary)

export default BccCollapseTitle
