import FormControl from '@material-ui/core/FormControl'
import { withStyles } from '@material-ui/core/styles'

const BccFormControl = withStyles({
  root: {},
})(FormControl)

export default BccFormControl
