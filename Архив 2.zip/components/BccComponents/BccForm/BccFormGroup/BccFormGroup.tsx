import FormGroup from '@material-ui/core/FormGroup'
import { withStyles } from '@material-ui/core/styles'

const BccFormGroup = withStyles({
  root: {},
})(FormGroup)

export default BccFormGroup
