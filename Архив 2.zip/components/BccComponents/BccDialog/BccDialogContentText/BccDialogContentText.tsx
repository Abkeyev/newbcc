import DialogContentText from '@material-ui/core/DialogContentText'
import { withStyles } from '@material-ui/core/styles'
import React from 'react'

const BccDialogContentText = withStyles({
  root: {},
})((props: any) => <DialogContentText {...props} />)

export default BccDialogContentText
