import DialogActions from '@material-ui/core/DialogActions'
import { withStyles } from '@material-ui/core/styles'
import React from 'react'

const BccDialogActions = withStyles({
  root: {},
})((props: any) => <DialogActions {...props} />)

export default BccDialogActions
