import TableContainer from '@material-ui/core/TableContainer'
import React from 'react'
import { withStyles } from '@material-ui/core/styles'

const BccTableContainer = withStyles({})((props: any) => (
  <TableContainer {...props} />
))

export default BccTableContainer
