import TableHead from '@material-ui/core/TableHead'
import React from 'react'
import { withStyles } from '@material-ui/core/styles'

const BccTableHead = withStyles({})((props: any) => <TableHead {...props} />)

export default BccTableHead
