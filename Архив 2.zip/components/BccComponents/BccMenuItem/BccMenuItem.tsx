import MenuItem from '@material-ui/core/MenuItem'
import { withStyles } from '@material-ui/core/styles'

const BccMenuItem = withStyles({
  root: {},
})(MenuItem)

export default BccMenuItem
