import { MainController } from "./MainController";

export class Api {
  main = new MainController();
}

export default new Api();
